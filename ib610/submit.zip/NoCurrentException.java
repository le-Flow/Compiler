public class NoCurrentException extends Exception {
}

